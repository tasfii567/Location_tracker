var modal = document.getElementsByClassName("popup")[0];
window.onclick = function(e) {
  if (e.target == modal) {
    modal.style.display = "none";
  }
}

