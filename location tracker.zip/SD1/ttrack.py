from time import time
import phonenumbers as ph
from phonenumbers import carrier
from phonenumbers import geocoder
from phonenumbers import timezone
number=input("Enter your number: ")
number = ph.parse(number)
tmz=timezone.time_zones_for_number(number)
sim=carrier.name_for_number(number, "en")
loc=geocoder.description_for_number(number, "en")
print("Place= ", tmz)
print("Sim= ", sim)
print("Country= ", loc)